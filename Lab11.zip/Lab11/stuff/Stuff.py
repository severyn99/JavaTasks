class Stuff:
    name = ""
    price = 0.0
    producer = ""
    material = ""
    weight = 0
    stuff_type = None
