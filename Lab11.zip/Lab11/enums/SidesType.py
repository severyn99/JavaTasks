from enum import Enum


class SidesType(Enum):
    HARDSIDED = 1
    SOFTSIDED = 2

