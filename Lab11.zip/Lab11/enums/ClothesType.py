from enum import Enum


class ClothesType(Enum):
    SHOES = 1
    TROUSERS = 2
    JACKET = 3
