from enum import Enum


class TypeOfFuel(Enum):
    LIQUID = 1
    TABLET = 2
    WOOD = 3
